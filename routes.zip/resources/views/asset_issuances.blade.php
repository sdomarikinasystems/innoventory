@extends('master.master')

@section('title')
Innoventory - Issuances
@endsection

@section('contents')
<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		<li class="breadcrumb-item active" aria-current="page">Home</li>
		<li class="breadcrumb-item active" aria-current="page">Issuances</li>
	</ol>
</nav>
<div class="container">
	<h4>Feature is under development</h4>
	<p class="text-muted">Issuances feature is currently on the works. Please standby for further updates about this feature.</p>
	<p class="mt-4">SDO Marikina IT Department</p>
</div>
@endsection